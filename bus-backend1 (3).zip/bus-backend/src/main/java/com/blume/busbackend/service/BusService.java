package com.blume.busbackend.service;


import com.blume.busbackend.Beans.BusBean;
import com.blume.busbackend.models.Bus;

import java.util.List;

public interface BusService {


    Bus create(BusBean bus);
    List<Bus> getAll();
    Bus edit(Long id,BusBean bus);
    void delete(Long busId);
    Bus find(Long busId);

    List<Bus> findByrouteId(Long routeId);
}
