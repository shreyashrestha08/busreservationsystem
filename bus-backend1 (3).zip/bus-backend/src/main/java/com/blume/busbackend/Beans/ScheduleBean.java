package com.blume.busbackend.Beans;


import lombok.Data;

@Data
public class ScheduleBean {

    private Long scheduleId;
    private Long stopId;
    private Long busId;
    private String busTime;
}
