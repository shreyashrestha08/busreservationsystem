package com.blume.busbackend.Beans;

import lombok.Data;

@Data
public class ScheduleBeaner {
    private Long scheduleId;
    private String busTime;
    private String busName;
    private String stopName;
}
