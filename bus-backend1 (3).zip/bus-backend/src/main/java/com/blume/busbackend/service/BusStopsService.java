package com.blume.busbackend.service;

import com.blume.busbackend.Beans.BusStopsBean;
import com.blume.busbackend.models.BookSeat;
import com.blume.busbackend.models.Bus;
import com.blume.busbackend.models.BusStops;

import java.util.List;

public interface BusStopsService {
    BusStops create(BusStopsBean busStops);
    List<BusStops> getAll();
    void delete(Long id);
    BusStops find(Long id);
    BusStops edit(BusStopsBean busStops , Long stopId);
    BusStops findByStopName(String stopsName);
    List<BusStops> findByrouteId(Long routeId);
}
