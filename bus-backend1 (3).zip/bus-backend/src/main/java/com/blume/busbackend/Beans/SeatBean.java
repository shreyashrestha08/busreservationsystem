package com.blume.busbackend.Beans;

import lombok.Data;

@Data
public class SeatBean {
    private String seatNo;
}
