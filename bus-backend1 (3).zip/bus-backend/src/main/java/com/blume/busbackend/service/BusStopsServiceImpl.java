package com.blume.busbackend.service;

import com.blume.busbackend.Beans.BusStopsBean;
import com.blume.busbackend.models.Bus;
import com.blume.busbackend.models.BusStops;
import com.blume.busbackend.models.Route;
import com.blume.busbackend.repo.BusStopsRepository;
import com.blume.busbackend.repo.RouteRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BusStopsServiceImpl implements BusStopsService{
    @Autowired
    RouteRepository routeRepository;
    @Autowired
    BusStopsRepository busStopsRepository;
    @Override
    public BusStops create(BusStopsBean busStops) {
        Route route = routeRepository.findById(busStops.getRouteId()).get();
        BusStops busStops1 = new BusStops();
        BeanUtils.copyProperties(busStops,busStops1,"routeId");
        busStops1.setRoute(route);
        return busStopsRepository.save(busStops1);
    }

    @Override
    public List<BusStops> getAll() {

        return busStopsRepository.findAll();
    }

    @Override
    public void delete(Long id) {
        busStopsRepository.deleteById(id);
    }

    @Override
    public BusStops find(Long id) {
        return busStopsRepository.findById(id).get();
    }

    @Override
    public BusStops edit(BusStopsBean busStops, Long stopId) {
        BusStops busStops1 = busStopsRepository.findById(stopId).get();
        Route route = routeRepository.findById(busStops.getRouteId()).get();
        busStops1.setStopName(busStops.getStopName());
        busStops1.setStopDist(busStops.getStopDist());
        busStops1.setStopRank(busStops.getStopRank());

        busStops1.setRoute(route);
        return busStopsRepository.save(busStops1);
    }

    @Override
    public BusStops findByStopName(String stopsName) {
        return busStopsRepository.findByStopName(stopsName);
    }

    @Override
    public List<BusStops> findByrouteId(Long routeId) {
        return busStopsRepository.findByRouteRouteId(routeId);
    }
}
