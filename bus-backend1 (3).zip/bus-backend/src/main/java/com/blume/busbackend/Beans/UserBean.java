package com.blume.busbackend.Beans;

import lombok.Data;

@Data
public class UserBean {
    private String email;
    private String password;
}
