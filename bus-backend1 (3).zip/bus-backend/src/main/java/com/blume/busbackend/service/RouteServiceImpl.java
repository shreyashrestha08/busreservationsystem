package com.blume.busbackend.service;
import com.blume.busbackend.models.Route;
import com.blume.busbackend.repo.RouteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class RouteServiceImpl implements RouteService {
    @Autowired
    RouteRepository routeRepository;

    @Override
    public Route create(Route route) {
        return routeRepository.save(route);
    }

    @Override
    public List<Route> getAll() {
        return routeRepository.findAll();
    }

    @Override
    public Route findById(Long routeId) {
        return routeRepository.findById(routeId).get();
    }

    @Override
    public void delete(Long routeId) {
        routeRepository.deleteById(routeId);
    }

    @Override
    public Route edit(Route route) {
        return routeRepository.save(route);
    }
}