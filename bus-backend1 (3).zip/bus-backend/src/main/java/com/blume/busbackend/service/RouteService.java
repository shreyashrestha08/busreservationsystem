package com.blume.busbackend.service;

import com.blume.busbackend.models.Route;

import java.util.List;
public interface RouteService {
    Route create(Route route);
    List<Route> getAll();
    Route findById(Long routeId);
    void delete(Long routeId);
    Route edit(Route route);

}