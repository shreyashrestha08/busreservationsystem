package com.blume.busbackend.controller;

import com.blume.busbackend.models.Route;
import com.blume.busbackend.service.RouteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/route")
public class RouteController {
    @Autowired
    RouteService routeService;

    @GetMapping("/all")
    List<Route> getAll() {
        return routeService.getAll();
    }

    @PostMapping("/add")
    Route create(@RequestBody Route route) {
        return routeService.create(route);
    }

    @PostMapping("/edit")
    Route update(@RequestBody Route route) {
        return routeService.create(route);
    }

    @GetMapping("/find/{id}")
    Route findById(@PathVariable("id") Long routeId) {
        return routeService.findById(routeId);
    }

    @DeleteMapping("/delete/{id}")
    String deleteId(@PathVariable("id") Long id) {
        routeService.delete(id);
        return "Deleted " + id;
    }
}
