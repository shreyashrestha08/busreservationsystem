package com.blume.busbackend.Beans;

import lombok.Data;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

@Data
public class BusBean {
    private Long busId;
    private String busName;
    private String busNo;
    private String busType;
    private Integer busCapacity;
    private Integer fare;
    private Integer speed;
    private Long routeId;
    private String busTime;
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;
}
